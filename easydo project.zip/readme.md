# easydo.websit
#### Video Demo:  <https://www.youtube.com/watch?v=DhYz_pf1Gy8&t=7s>
#### Description: it's a website use as a freelancer work
TODO